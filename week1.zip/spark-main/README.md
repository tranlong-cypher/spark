# spark
upload 'train.txt' before runing colab <br>
run install pyspark before fun cell 1
